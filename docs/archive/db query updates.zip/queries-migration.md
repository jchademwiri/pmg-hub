# queries.ts → queries/ Migration Guide

## What changed

`packages/db/src/queries.ts` (one large file) is replaced by
`packages/db/src/queries/` (one file per domain). All function signatures and
return types are **identical** — this is a pure refactor, no behaviour changes.

```
packages/db/src/queries/
  index.ts       ← drop-in replacement for queries.ts
  income.ts
  expenses.ts
  divisions.ts
  clients.ts
  leads.ts
  ledger.ts
  snapshots.ts
  reports.ts
  billing.ts     ← was already here, now included in index.ts
```

---

## Step-by-step

### 1. Copy the new files into your repo

Copy every file from the `queries/` folder provided into:

```
packages/db/src/queries/
```

`billing.ts` is already there — leave it untouched.

---

### 2. Update `packages/db/src/index.ts`

Find this line:

```ts
export * from "./queries";
```

Change it to:

```ts
export * from "./queries/index";
```

That's the only change needed in `index.ts`. Everything else re-exports
transparently.

---

### 3. Delete the old flat file

```bash
rm packages/db/src/queries.ts
```

---

### 4. Fix the one explicit named import in `index.ts`

Your current `packages/db/src/index.ts` has several named imports that
reference `'./queries'` directly, for example:

```ts
export { getAllLedgerEntries, getLedgerById, ... } from './queries';
export { getAllSnapshots, getSnapshotByPeriod, insertSnapshot } from './queries';
export { getClientsWithIncomeCount, getClientById, setClientActive } from './queries';
export { getDivisionWithStatsById, setDivisionActive } from './queries';
export { getAllExpenseCategories, getExpenseCategoryById } from './queries';
```

These all still work after step 2 because `'./queries'` now resolves to
`'./queries/index'`. **You do not need to change them**, but you can update
them to point to the specific file for clarity:

```ts
// optional — clearer but not required
export { getAllLedgerEntries, getLedgerById, ... } from './queries/ledger';
export { getAllSnapshots, getSnapshotByPeriod, insertSnapshot } from './queries/snapshots';
export { getClientsWithIncomeCount, getClientById, setClientActive } from './queries/clients';
export { getDivisionWithStatsById, setDivisionActive } from './queries/divisions';
export { getAllExpenseCategories, getExpenseCategoryById } from './queries/expenses';
```

---

### 5. Verify — no import changes needed in your app

Because everything re-exports through `packages/db/src/index.ts →
queries/index.ts`, all existing imports in your Next.js app like:

```ts
import { getAllIncome, getLeadsByStatus } from '@repo/db';
```

continue to work without any changes.

---

### 6. One thing to watch — `getDistinctYears`

`getDistinctYears` queries both `income` and `expenses` tables. It lives in
`queries/income.ts` (since it was originally in `queries.ts` near the income
helpers). If that feels wrong to you, move it to `queries/reports.ts` — it's
exported from `index.ts` either way so the public API doesn't change.

---

## Quick sanity check after migration

```bash
# TypeScript should compile clean
pnpm --filter @repo/db tsc --noEmit

# Or if you use turbo
turbo run type-check
```

If you see any "module not found" errors, check that `billing.ts` is still at
`packages/db/src/queries/billing.ts` and not accidentally moved.
