import { db } from '../client';
import { expenses } from '../schema/expenses';
import { divisions } from '../schema/divisions';
import { clients } from '../schema/clients';
import { expenseCategories } from '../schema/expense-categories';
import { sql, eq, desc, asc, and } from 'drizzle-orm';
import type { ExpenseCategory } from '../schema/expense-categories';

export type ExpenseRow = {
  id: string;
  date: string;
  divisionId: string;
  divisionName: string;
  clientId: string | null;
  clientName: string | null;
  category: string;
  description: string | null;
  amount: string;
  createdAt: Date;
  updatedAt: Date | null;
};

export async function getAllExpenses(
  filters?: { divisionId?: string; category?: string; month?: string },
  pageObj?: { page: number; pageSize: number },
): Promise<{ data: ExpenseRow[]; total: number; sum: number }> {
  const conditions = [];
  if (filters?.divisionId) conditions.push(eq(expenses.divisionId, filters.divisionId));
  if (filters?.category) conditions.push(eq(expenses.category, filters.category));
  if (filters?.month) conditions.push(sql`TO_CHAR(${expenses.date}, 'YYYY-MM') = ${filters.month}`);

  const query = db
    .select({
      id: expenses.id,
      date: sql<string>`${expenses.date}::text`,
      divisionId: expenses.divisionId,
      divisionName: divisions.name,
      clientId: expenses.clientId,
      clientName: clients.name,
      category: expenses.category,
      description: expenses.description,
      amount: expenses.amount,
      createdAt: expenses.createdAt,
      updatedAt: expenses.updatedAt,
    })
    .from(expenses)
    .innerJoin(divisions, eq(expenses.divisionId, divisions.id))
    .leftJoin(clients, eq(expenses.clientId, clients.id))
    .orderBy(desc(expenses.date));

  let finalQuery = conditions.length > 0 ? query.where(and(...conditions)) : query;

  const countQuery = db
    .select({
      count: sql<number>`count(*)::int`,
      sum: sql<number>`COALESCE(SUM(${expenses.amount}), 0)::numeric`,
    })
    .from(expenses);
  if (conditions.length > 0) countQuery.where(and(...conditions));

  const [totalRes] = await countQuery;
  const total = totalRes?.count ?? 0;
  const sumAmount = Number(totalRes?.sum ?? 0);

  if (pageObj) {
    finalQuery = finalQuery
      .limit(pageObj.pageSize)
      .offset((pageObj.page - 1) * pageObj.pageSize) as any;
  }

  const data = await finalQuery;
  return { data, total, sum: sumAmount };
}

export async function getExpenseById(id: string): Promise<ExpenseRow | null> {
  const result = await db
    .select({
      id: expenses.id,
      date: sql<string>`${expenses.date}::text`,
      divisionId: expenses.divisionId,
      divisionName: divisions.name,
      clientId: expenses.clientId,
      clientName: clients.name,
      category: expenses.category,
      description: expenses.description,
      amount: expenses.amount,
      createdAt: expenses.createdAt,
      updatedAt: expenses.updatedAt,
    })
    .from(expenses)
    .innerJoin(divisions, eq(expenses.divisionId, divisions.id))
    .leftJoin(clients, eq(expenses.clientId, clients.id))
    .where(eq(expenses.id, id));

  return result[0] ?? null;
}

export async function getDistinctExpenseMonths(): Promise<string[]> {
  const result = await db
    .selectDistinct({ month: sql<string>`TO_CHAR(${expenses.date}, 'YYYY-MM')` })
    .from(expenses)
    .orderBy(sql`TO_CHAR(${expenses.date}, 'YYYY-MM') ASC`);

  return result.map((r) => r.month);
}

export async function getTotalExpenses(): Promise<number> {
  const result = await db
    .select({ total: sql<string>`COALESCE(SUM(${expenses.amount}), '0')` })
    .from(expenses);
  return Number(result[0]!.total);
}

export async function getMoMExpensesSnapshot(): Promise<{
  currentExpenses: number;
  previousExpenses: number;
}> {
  const result = await db.execute(sql`
    SELECT
      COALESCE(SUM(CASE WHEN date >= DATE_TRUNC('month', NOW())
                         AND date <  DATE_TRUNC('month', NOW()) + INTERVAL '1 month'
                        THEN amount END), 0) AS current_expenses,
      COALESCE(SUM(CASE WHEN date >= DATE_TRUNC('month', NOW()) - INTERVAL '1 month'
                         AND date <  DATE_TRUNC('month', NOW())
                        THEN amount END), 0) AS previous_expenses
    FROM expenses
  `);
  const row = result.rows[0] as { current_expenses: string; previous_expenses: string };
  return {
    currentExpenses: Number(row.current_expenses),
    previousExpenses: Number(row.previous_expenses),
  };
}

export async function getExpensesByCategoryForYear(
  year: number,
): Promise<{ category: string; total: number }[]> {
  const result: { category: string; total: string }[] = await db
    .select({
      category: expenses.category,
      total: sql<string>`COALESCE(SUM(${expenses.amount}), '0')`,
    })
    .from(expenses)
    .where(sql`EXTRACT(YEAR FROM ${expenses.date}) = ${year}`)
    .groupBy(expenses.category)
    .orderBy(desc(sql`SUM(${expenses.amount})`));
  return result.map((r) => ({ category: r.category, total: Number(r.total) }));
}

export async function getAllExpenseCategories(): Promise<{ id: string; name: string }[]> {
  return db
    .select({ id: expenseCategories.id, name: expenseCategories.name })
    .from(expenseCategories)
    .orderBy(asc(expenseCategories.name));
}

export async function getExpenseCategoryById(id: string): Promise<ExpenseCategory | null> {
  const result = await db
    .select()
    .from(expenseCategories)
    .where(eq(expenseCategories.id, id));

  return result[0] ?? null;
}
