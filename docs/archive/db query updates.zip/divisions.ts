import { db } from '../client';
import { divisions } from '../schema/divisions';
import { income } from '../schema/income';
import { expenses } from '../schema/expenses';
import { leads } from '../schema/leads';
import { sql, eq, desc, asc } from 'drizzle-orm';

export type DivisionRow = {
  id: string;
  name: string;
  isActive: boolean;
  totalIncome: number;
  totalExpenses: number;
  netProfit: number;
  leadCount: number;
};

export async function getAllDivisions(): Promise<{ id: string; name: string }[]> {
  return db
    .select({ id: divisions.id, name: divisions.name })
    .from(divisions)
    .orderBy(asc(divisions.name));
}

export async function getDivisionsWithStats(): Promise<DivisionRow[]> {
  const result = await db.execute(sql`
    SELECT
      d.id,
      d.name,
      d.is_active                            AS "isActive",
      COALESCE(i.total_income,   0)::numeric AS "totalIncome",
      COALESCE(e.total_expenses, 0)::numeric AS "totalExpenses",
      (COALESCE(i.total_income, 0) - COALESCE(e.total_expenses, 0))::numeric AS "netProfit",
      COALESCE(l.lead_count,     0)::integer AS "leadCount"
    FROM divisions d
    LEFT JOIN (
      SELECT division_id, SUM(amount) AS total_income
      FROM income GROUP BY division_id
    ) i ON i.division_id = d.id
    LEFT JOIN (
      SELECT division_id, SUM(amount) AS total_expenses
      FROM expenses GROUP BY division_id
    ) e ON e.division_id = d.id
    LEFT JOIN (
      SELECT division_id, COUNT(*) AS lead_count
      FROM leads GROUP BY division_id
    ) l ON l.division_id = d.id
    ORDER BY d.name ASC
  `);

  return (result.rows as any[]).map((row) => ({
    id:            row.id,
    name:          row.name,
    isActive:      row.isActive,
    totalIncome:   Number(row.totalIncome),
    totalExpenses: Number(row.totalExpenses),
    netProfit:     Number(row.netProfit),
    leadCount:     Number(row.leadCount),
  }));
}

export async function getDivisionWithStatsById(id: string): Promise<DivisionRow | null> {
  const result = await db.execute(sql`
    SELECT
      d.id,
      d.name,
      d.is_active                            AS "isActive",
      COALESCE(i.total_income,   0)::numeric AS "totalIncome",
      COALESCE(e.total_expenses, 0)::numeric AS "totalExpenses",
      (COALESCE(i.total_income, 0) - COALESCE(e.total_expenses, 0))::numeric AS "netProfit",
      COALESCE(l.lead_count,     0)::integer AS "leadCount"
    FROM divisions d
    LEFT JOIN (
      SELECT division_id, SUM(amount) AS total_income
      FROM income WHERE division_id = ${id} GROUP BY division_id
    ) i ON i.division_id = d.id
    LEFT JOIN (
      SELECT division_id, SUM(amount) AS total_expenses
      FROM expenses WHERE division_id = ${id} GROUP BY division_id
    ) e ON e.division_id = d.id
    LEFT JOIN (
      SELECT division_id, COUNT(*) AS lead_count
      FROM leads WHERE division_id = ${id} GROUP BY division_id
    ) l ON l.division_id = d.id
    WHERE d.id = ${id}
  `);

  const row = result.rows[0] as any | undefined;
  if (!row) return null;

  return {
    id:            row.id,
    name:          row.name,
    isActive:      row.isActive,
    totalIncome:   Number(row.totalIncome),
    totalExpenses: Number(row.totalExpenses),
    netProfit:     Number(row.netProfit),
    leadCount:     Number(row.leadCount),
  };
}

export async function setDivisionActive(id: string, isActive: boolean): Promise<void> {
  await db.update(divisions).set({ isActive, updatedAt: new Date() }).where(eq(divisions.id, id));
}

export async function getRevenueByDivision(): Promise<{ divisionName: string; total: number }[]> {
  const result: { divisionName: string; total: string }[] = await db
    .select({
      divisionName: divisions.name,
      total: sql<string>`COALESCE(SUM(${income.amount}), '0')`,
    })
    .from(income)
    .innerJoin(divisions, eq(income.divisionId, divisions.id))
    .groupBy(divisions.name)
    .orderBy(desc(sql`SUM(${income.amount})`));
  return result.map((r) => ({ divisionName: r.divisionName, total: Number(r.total) }));
}

export async function getDivisionRevenueSeries(
  months: number,
): Promise<{ month: string; divisionName: string; total: number }[]> {
  const result: { month: string; divisionName: string; total: string }[] = await db
    .select({
      month: sql<string>`TO_CHAR(${income.date}, 'YYYY-MM')`,
      divisionName: divisions.name,
      total: sql<string>`COALESCE(SUM(${income.amount}), '0')`,
    })
    .from(income)
    .innerJoin(divisions, eq(income.divisionId, divisions.id))
    .where(
      sql`${income.date} >= DATE_TRUNC('month', NOW()) - INTERVAL '${sql.raw(String(months - 1))} months'`,
    )
    .groupBy(sql`TO_CHAR(${income.date}, 'YYYY-MM')`, divisions.name)
    .orderBy(sql`TO_CHAR(${income.date}, 'YYYY-MM') ASC`, asc(divisions.name));
  return result.map((r) => ({ month: r.month, divisionName: r.divisionName, total: Number(r.total) }));
}

export async function getDivisionRevenueCurrentMonth(): Promise<
  { month: string; divisionName: string; total: number }[]
> {
  const result: { month: string; divisionName: string; total: string }[] = await db
    .select({
      month: sql<string>`TO_CHAR(${income.date}, 'YYYY-MM')`,
      divisionName: divisions.name,
      total: sql<string>`COALESCE(SUM(${income.amount}), '0')`,
    })
    .from(income)
    .innerJoin(divisions, eq(income.divisionId, divisions.id))
    .where(
      sql`${income.date} >= DATE_TRUNC('month', NOW()) AND ${income.date} < DATE_TRUNC('month', NOW()) + INTERVAL '1 month'`,
    )
    .groupBy(sql`TO_CHAR(${income.date}, 'YYYY-MM')`, divisions.name)
    .orderBy(asc(divisions.name));
  return result.map((r) => ({ month: r.month, divisionName: r.divisionName, total: Number(r.total) }));
}

export async function getDivisionRevenuePreviousMonth(): Promise<
  { month: string; divisionName: string; total: number }[]
> {
  const result: { month: string; divisionName: string; total: string }[] = await db
    .select({
      month: sql<string>`TO_CHAR(${income.date}, 'YYYY-MM')`,
      divisionName: divisions.name,
      total: sql<string>`COALESCE(SUM(${income.amount}), '0')`,
    })
    .from(income)
    .innerJoin(divisions, eq(income.divisionId, divisions.id))
    .where(
      sql`${income.date} >= DATE_TRUNC('month', NOW()) - INTERVAL '1 month' AND ${income.date} < DATE_TRUNC('month', NOW())`,
    )
    .groupBy(sql`TO_CHAR(${income.date}, 'YYYY-MM')`, divisions.name)
    .orderBy(asc(divisions.name));
  return result.map((r) => ({ month: r.month, divisionName: r.divisionName, total: Number(r.total) }));
}

export async function getDivisionRevenueYTD(): Promise<
  { month: string; divisionName: string; total: number }[]
> {
  const result: { month: string; divisionName: string; total: string }[] = await db
    .select({
      month: sql<string>`TO_CHAR(${income.date}, 'YYYY-MM')`,
      divisionName: divisions.name,
      total: sql<string>`COALESCE(SUM(${income.amount}), '0')`,
    })
    .from(income)
    .innerJoin(divisions, eq(income.divisionId, divisions.id))
    .where(sql`${income.date} >= DATE_TRUNC('year', NOW() - INTERVAL '2 months') + INTERVAL '2 months'`)
    .groupBy(sql`TO_CHAR(${income.date}, 'YYYY-MM')`, divisions.name)
    .orderBy(sql`TO_CHAR(${income.date}, 'YYYY-MM') ASC`, asc(divisions.name));
  return result.map((r) => ({ month: r.month, divisionName: r.divisionName, total: Number(r.total) }));
}

export async function getMonthlyRevenueByDivision(
  months = 6,
): Promise<{ month: string; divisionName: string; total: number }[]> {
  return getDivisionRevenueSeries(months);
}

export async function getMonthlyRevenueByDivisionForYear(
  year: number,
): Promise<{ month: string; divisionName: string; total: number }[]> {
  const result: { month: string; divisionName: string; total: string }[] = await db
    .select({
      month: sql<string>`TO_CHAR(${income.date}, 'YYYY-MM')`,
      divisionName: divisions.name,
      total: sql<string>`COALESCE(SUM(${income.amount}), '0')`,
    })
    .from(income)
    .innerJoin(divisions, eq(income.divisionId, divisions.id))
    .where(sql`EXTRACT(YEAR FROM ${income.date}) = ${year}`)
    .groupBy(sql`TO_CHAR(${income.date}, 'YYYY-MM')`, divisions.name)
    .orderBy(sql`TO_CHAR(${income.date}, 'YYYY-MM') ASC`, asc(divisions.name));
  return result.map((r) => ({ month: r.month, divisionName: r.divisionName, total: Number(r.total) }));
}
