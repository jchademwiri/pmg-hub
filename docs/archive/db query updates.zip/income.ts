import { db } from '../client';
import { income } from '../schema/income';
import { divisions } from '../schema/divisions';
import { clients } from '../schema/clients';
import { sql, eq, desc, asc, and } from 'drizzle-orm';

export type IncomeRow = {
  id: string;
  date: string;
  divisionId: string;
  divisionName: string;
  clientId: string | null;
  clientName: string | null;
  description: string | null;
  amount: string;
};

export async function getAllIncome(
  filters?: { divisionId?: string; month?: string; year?: number; clientId?: string },
  pageObj?: { page: number; pageSize: number },
): Promise<{ data: IncomeRow[]; total: number; sum: number }> {
  const conditions = [];
  if (filters?.divisionId) conditions.push(eq(income.divisionId, filters.divisionId));
  if (filters?.clientId) conditions.push(eq(income.clientId, filters.clientId));
  if (filters?.month) conditions.push(sql`TO_CHAR(${income.date}, 'YYYY-MM') = ${filters.month}`);
  if (filters?.year) {
    conditions.push(
      sql`${income.date} >= ${`${filters.year}-03-01`}`,
      sql`${income.date} < ${`${filters.year + 1}-03-01`}`,
    );
  }

  const query = db
    .select({
      id: income.id,
      date: sql<string>`${income.date}::text`,
      divisionId: income.divisionId,
      divisionName: divisions.name,
      clientId: income.clientId,
      clientName: clients.name,
      description: income.description,
      amount: income.amount,
    })
    .from(income)
    .innerJoin(divisions, eq(income.divisionId, divisions.id))
    .leftJoin(clients, eq(income.clientId, clients.id))
    .orderBy(desc(income.date));

  let finalQuery = conditions.length > 0 ? query.where(and(...conditions)) : query;

  const countQuery = db
    .select({
      count: sql<number>`count(*)::int`,
      sum: sql<number>`COALESCE(SUM(${income.amount}), 0)::numeric`,
    })
    .from(income);
  if (conditions.length > 0) countQuery.where(and(...conditions));

  const [totalRes] = await countQuery;
  const total = totalRes?.count ?? 0;
  const sumAmount = Number(totalRes?.sum ?? 0);

  if (pageObj) {
    finalQuery = finalQuery
      .limit(pageObj.pageSize)
      .offset((pageObj.page - 1) * pageObj.pageSize) as any;
  }

  const data = await finalQuery;
  return { data, total, sum: sumAmount };
}

export async function getIncomeById(id: string): Promise<IncomeRow | null> {
  const result = await db
    .select({
      id: income.id,
      date: sql<string>`${income.date}::text`,
      divisionId: income.divisionId,
      divisionName: divisions.name,
      clientId: income.clientId,
      clientName: clients.name,
      description: income.description,
      amount: income.amount,
    })
    .from(income)
    .innerJoin(divisions, eq(income.divisionId, divisions.id))
    .leftJoin(clients, eq(income.clientId, clients.id))
    .where(eq(income.id, id));

  return result[0] ?? null;
}

export async function getDistinctIncomeMonths(): Promise<string[]> {
  const result = await db
    .selectDistinct({ month: sql<string>`TO_CHAR(${income.date}, 'YYYY-MM')` })
    .from(income)
    .orderBy(sql`TO_CHAR(${income.date}, 'YYYY-MM') DESC`);

  return result.map((r) => r.month);
}

export async function getTotalRevenue(): Promise<number> {
  const result = await db
    .select({ total: sql<string>`COALESCE(SUM(${income.amount}), '0')` })
    .from(income);
  return Number(result[0]!.total);
}

export async function getMoMRevenueSnapshot(): Promise<{
  currentRevenue: number;
  previousRevenue: number;
}> {
  const result = await db.execute(sql`
    SELECT
      COALESCE(SUM(CASE WHEN date >= DATE_TRUNC('month', NOW())
                         AND date <  DATE_TRUNC('month', NOW()) + INTERVAL '1 month'
                        THEN amount END), 0) AS current_revenue,
      COALESCE(SUM(CASE WHEN date >= DATE_TRUNC('month', NOW()) - INTERVAL '1 month'
                         AND date <  DATE_TRUNC('month', NOW())
                        THEN amount END), 0) AS previous_revenue
    FROM income
  `);
  const row = result.rows[0] as { current_revenue: string; previous_revenue: string };
  return {
    currentRevenue: Number(row.current_revenue),
    previousRevenue: Number(row.previous_revenue),
  };
}

export async function getDistinctYears(): Promise<number[]> {
  const result = await db.execute(sql`
    SELECT year FROM (
      SELECT DISTINCT EXTRACT(YEAR FROM date)::integer AS year FROM income
      UNION
      SELECT DISTINCT EXTRACT(YEAR FROM date)::integer AS year FROM expenses
    ) combined
    ORDER BY year DESC
  `);
  return (result.rows as { year: number }[]).map((r) => Number(r.year));
}
