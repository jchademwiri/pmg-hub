import { db } from '../client';
import { income } from '../schema/income';
import { expenses } from '../schema/expenses';
import { sql } from 'drizzle-orm';
import { ACCOUNT_RATES } from '../accounts';

// ── Period Summary ────────────────────────────────────────────────────────────

export type PeriodSummary = {
  revenue: number;
  expenses: number;
  pmgShare: number;
  profitPool: number;
  salary: number;
  reinvest: number;
  reserve: number;
  flex: number;
};

export async function getFinancialSummaryForPeriod(
  startExpr: string,
  endExpr: string,
): Promise<PeriodSummary> {
  const revResult = await db.execute(sql`
    SELECT COALESCE(SUM(amount), 0) AS total
    FROM income
    WHERE date >= ${sql.raw(startExpr)} AND date < ${sql.raw(endExpr)}
  `);
  const expResult = await db.execute(sql`
    SELECT COALESCE(SUM(amount), 0) AS total
    FROM expenses
    WHERE date >= ${sql.raw(startExpr)} AND date < ${sql.raw(endExpr)}
  `);

  const revenue  = Number((revResult.rows[0] as { total: string }).total);
  const expTotal = Number((expResult.rows[0] as { total: string }).total);
  const pmgShare = revenue * ACCOUNT_RATES.pmg_share;
  const profitPool = revenue - expTotal - pmgShare;

  return {
    revenue,
    expenses:   expTotal,
    pmgShare,
    profitPool,
    salary:   profitPool * ACCOUNT_RATES.salary,
    reinvest: profitPool * ACCOUNT_RATES.reinvest,
    reserve:  profitPool * ACCOUNT_RATES.reserve,
    flex:     profitPool * ACCOUNT_RATES.flex,
  };
}

export async function getCurrentMonthSummary(): Promise<PeriodSummary> {
  return getFinancialSummaryForPeriod(
    "DATE_TRUNC('month', NOW())",
    "DATE_TRUNC('month', NOW()) + INTERVAL '1 month'",
  );
}

export async function getPreviousMonthSummary(): Promise<PeriodSummary> {
  return getFinancialSummaryForPeriod(
    "DATE_TRUNC('month', NOW()) - INTERVAL '1 month'",
    "DATE_TRUNC('month', NOW())",
  );
}

export async function getYTDSummary(): Promise<PeriodSummary> {
  return getFinancialSummaryForPeriod(
    "DATE_TRUNC('year', NOW() - INTERVAL '2 months') + INTERVAL '2 months'",
    "NOW() + INTERVAL '1 day'",
  );
}

export async function getPreviousYearYTDSummary(): Promise<PeriodSummary> {
  return getFinancialSummaryForPeriod(
    "DATE_TRUNC('year', NOW() - INTERVAL '2 months') - INTERVAL '1 year' + INTERVAL '2 months'",
    "NOW() - INTERVAL '1 year' + INTERVAL '1 day'",
  );
}

// ── Monthly Financials ────────────────────────────────────────────────────────

export async function getMonthlyFinancials(): Promise<
  { month: string; revenue: number; expenses: number }[]
> {
  const result = await db.execute(sql`
    WITH rev AS (
      SELECT TO_CHAR(date, 'YYYY-MM') AS month, COALESCE(SUM(amount), 0) AS revenue
      FROM income WHERE EXTRACT(YEAR FROM date) = EXTRACT(YEAR FROM NOW())
      GROUP BY TO_CHAR(date, 'YYYY-MM')
    ),
    exp AS (
      SELECT TO_CHAR(date, 'YYYY-MM') AS month, COALESCE(SUM(amount), 0) AS expenses
      FROM expenses WHERE EXTRACT(YEAR FROM date) = EXTRACT(YEAR FROM NOW())
      GROUP BY TO_CHAR(date, 'YYYY-MM')
    )
    SELECT COALESCE(rev.month, exp.month) AS month,
           COALESCE(rev.revenue, 0) AS revenue,
           COALESCE(exp.expenses, 0) AS expenses
    FROM rev FULL OUTER JOIN exp ON rev.month = exp.month
    ORDER BY month ASC
  `);
  return (result.rows as { month: string; revenue: string; expenses: string }[]).map((r) => ({
    month:    r.month,
    revenue:  Number(r.revenue),
    expenses: Number(r.expenses),
  }));
}

export async function getMonthlyFinancialsForYear(
  year: number,
): Promise<{ month: string; revenue: number; expenses: number }[]> {
  const result = await db.execute(sql`
    WITH rev AS (
      SELECT TO_CHAR(date, 'YYYY-MM') AS month, COALESCE(SUM(amount), 0) AS revenue
      FROM income WHERE EXTRACT(YEAR FROM date) = ${year}
      GROUP BY TO_CHAR(date, 'YYYY-MM')
    ),
    exp AS (
      SELECT TO_CHAR(date, 'YYYY-MM') AS month, COALESCE(SUM(amount), 0) AS expenses
      FROM expenses WHERE EXTRACT(YEAR FROM date) = ${year}
      GROUP BY TO_CHAR(date, 'YYYY-MM')
    )
    SELECT COALESCE(rev.month, exp.month) AS month,
           COALESCE(rev.revenue, 0) AS revenue,
           COALESCE(exp.expenses, 0) AS expenses
    FROM rev FULL OUTER JOIN exp ON rev.month = exp.month
    ORDER BY 1 ASC
  `);
  return (result.rows as { month: string; revenue: string; expenses: string }[]).map((r) => ({
    month:    r.month,
    revenue:  Number(r.revenue),
    expenses: Number(r.expenses),
  }));
}

// ── MoM combined snapshot ─────────────────────────────────────────────────────

export async function getMoMSnapshot(): Promise<{
  currentRevenue: number;
  previousRevenue: number;
  currentExpenses: number;
  previousExpenses: number;
}> {
  const revResult = await db.execute(sql`
    SELECT
      COALESCE(SUM(CASE WHEN date >= DATE_TRUNC('month', NOW())
                         AND date <  DATE_TRUNC('month', NOW()) + INTERVAL '1 month'
                        THEN amount END), 0) AS current_revenue,
      COALESCE(SUM(CASE WHEN date >= DATE_TRUNC('month', NOW()) - INTERVAL '1 month'
                         AND date <  DATE_TRUNC('month', NOW())
                        THEN amount END), 0) AS previous_revenue
    FROM income
  `);
  const expResult = await db.execute(sql`
    SELECT
      COALESCE(SUM(CASE WHEN date >= DATE_TRUNC('month', NOW())
                         AND date <  DATE_TRUNC('month', NOW()) + INTERVAL '1 month'
                        THEN amount END), 0) AS current_expenses,
      COALESCE(SUM(CASE WHEN date >= DATE_TRUNC('month', NOW()) - INTERVAL '1 month'
                         AND date <  DATE_TRUNC('month', NOW())
                        THEN amount END), 0) AS previous_expenses
    FROM expenses
  `);

  const inc = revResult.rows[0] as { current_revenue: string; previous_revenue: string };
  const exp = expResult.rows[0] as { current_expenses: string; previous_expenses: string };

  return {
    currentRevenue:   Number(inc.current_revenue),
    previousRevenue:  Number(inc.previous_revenue),
    currentExpenses:  Number(exp.current_expenses),
    previousExpenses: Number(exp.previous_expenses),
  };
}

export async function getExpensesByDivision(): Promise<{ divisionName: string; total: number }[]> {
  const { divisions } = await import('../schema/divisions');
  const { eq, desc } = await import('drizzle-orm');

  const result: { divisionName: string; total: string }[] = await db
    .select({
      divisionName: divisions.name,
      total: sql<string>`COALESCE(SUM(${expenses.amount}), '0')`,
    })
    .from(expenses)
    .innerJoin(divisions, eq(expenses.divisionId, divisions.id))
    .groupBy(divisions.name)
    .orderBy(desc(sql`SUM(${expenses.amount})`));

  return result.map((r) => ({ divisionName: r.divisionName, total: Number(r.total) }));
}
