import { db } from '../client';
import { clients } from '../schema/clients';
import { income } from '../schema/income';
import { sql, eq, asc } from 'drizzle-orm';
import type { Client } from '../schema/clients';

export type ClientWithIncomeCount = {
  id: string;
  name: string;
  businessName: string | null;
  email: string | null;
  phone: string | null;
  isActive: boolean;
  createdAt: Date;
  incomeCount: number;
};

export async function getAllClients(): Promise<
  { id: string; name: string; businessName: string | null }[]
> {
  return db
    .select({ id: clients.id, name: clients.name, businessName: clients.businessName })
    .from(clients)
    .orderBy(asc(clients.name));
}

export async function getClientsWithIncomeCount(): Promise<ClientWithIncomeCount[]> {
  const result = await db
    .select({
      id: clients.id,
      name: clients.name,
      businessName: clients.businessName,
      email: clients.email,
      phone: clients.phone,
      isActive: clients.isActive,
      createdAt: clients.createdAt,
      incomeCount: sql<number>`CAST(COUNT(${income.id}) AS INTEGER)`,
    })
    .from(clients)
    .leftJoin(income, eq(income.clientId, clients.id))
    .groupBy(clients.id)
    .orderBy(asc(clients.name));

  return result;
}

export async function getClientById(id: string): Promise<Client | null> {
  const result = await db.select().from(clients).where(eq(clients.id, id));
  return result[0] ?? null;
}

export async function setClientActive(id: string, isActive: boolean): Promise<void> {
  await db.update(clients).set({ isActive, updatedAt: new Date() }).where(eq(clients.id, id));
}
